License
-------

.. include:: ../../LICENSE.rst

