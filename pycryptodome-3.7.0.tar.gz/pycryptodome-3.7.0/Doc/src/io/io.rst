``Crypto.IO`` package
=====================

Modules for reading and writing cryptographic data.

* :doc:`pem`
* :doc:`pkcs8`

.. toctree::
    :hidden:

    pem
    pkcs8
